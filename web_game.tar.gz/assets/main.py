import asyncio
import math
import random
import sys

import pygame


# Window settings
WINDOW_WIDTH = 450
WINDOW_HEIGHT = 800
FPS = 60

# Battle arena settings
ARENA_X = 25
ARENA_Y = 200
ARENA_SIZE = 400

# Game settings
STARTING_HP = 100
DAMAGE = 10
BALL_RADIUS = 38
BALL_SPEED = 7.2
COLLISION_COOLDOWN = 0.35

# Colors
WHITE = (255, 255, 255)
BLACK = (20, 20, 20)
GRAY = (80, 80, 80)
RED = (220, 55, 55)
BLUE = (55, 115, 230)
GREEN = (70, 210, 95)


START_BUTTON_RECT = pygame.Rect(WINDOW_WIDTH // 2 - 80, 420, 160, 55)
PLAY_AGAIN_BUTTON_RECT = pygame.Rect(WINDOW_WIDTH // 2 - 95, 430, 190, 55)
MAIN_MENU_BUTTON_RECT = pygame.Rect(WINDOW_WIDTH // 2 - 95, 505, 190, 55)


def create_ball(x, y, vx, vy, color):
    """Create a ball dictionary with position, velocity, HP, and color."""
    return {
        "x": float(x),
        "y": float(y),
        "vx": float(vx),
        "vy": float(vy),
        "hp": STARTING_HP,
        "color": color,
    }


def reset_game():
    """Return fresh game state for a new round."""
    red_ball = create_ball(150, 320, BALL_SPEED, BALL_SPEED * 0.75, RED)
    blue_ball = create_ball(300, 480, -BALL_SPEED, -BALL_SPEED * 0.65, BLUE)

    return {
        "red": red_ball,
        "blue": blue_ball,
        "last_collision_time": -COLLISION_COOLDOWN,
        "winner": None,
    }


def move_ball(ball):
    """Move one ball and bounce it off the square arena walls."""
    ball["x"] += ball["vx"]
    ball["y"] += ball["vy"]

    arena_left = ARENA_X
    arena_right = ARENA_X + ARENA_SIZE
    arena_top = ARENA_Y
    arena_bottom = ARENA_Y + ARENA_SIZE
    hit_wall = False

    if ball["x"] - BALL_RADIUS <= arena_left:
        ball["x"] = arena_left + BALL_RADIUS
        ball["vx"] = -ball["vx"]
        hit_wall = True
    elif ball["x"] + BALL_RADIUS >= arena_right:
        ball["x"] = arena_right - BALL_RADIUS
        ball["vx"] = -ball["vx"]
        hit_wall = True

    if ball["y"] - BALL_RADIUS <= arena_top:
        ball["y"] = arena_top + BALL_RADIUS
        ball["vy"] = -ball["vy"]
        hit_wall = True
    elif ball["y"] + BALL_RADIUS >= arena_bottom:
        ball["y"] = arena_bottom - BALL_RADIUS
        ball["vy"] = -ball["vy"]
        hit_wall = True

    # A small angle change prevents long repeated paths.
    if hit_wall:
        randomize_direction(ball)


def distance_between(ball_a, ball_b):
    dx = ball_b["x"] - ball_a["x"]
    dy = ball_b["y"] - ball_a["y"]
    return math.hypot(dx, dy)


def keep_ball_speed(ball):
    """Keep the ball moving at the chosen game speed after a bounce."""
    current_speed = math.hypot(ball["vx"], ball["vy"])

    if current_speed == 0:
        ball["vx"] = BALL_SPEED
        ball["vy"] = 0
        return

    ball["vx"] = ball["vx"] / current_speed * BALL_SPEED
    ball["vy"] = ball["vy"] / current_speed * BALL_SPEED


def randomize_direction(ball, max_angle_degrees=12):
    """Rotate a ball's movement direction slightly while keeping its speed."""
    angle = math.radians(random.uniform(-max_angle_degrees, max_angle_degrees))
    old_vx = ball["vx"]
    old_vy = ball["vy"]

    ball["vx"] = old_vx * math.cos(angle) - old_vy * math.sin(angle)
    ball["vy"] = old_vx * math.sin(angle) + old_vy * math.cos(angle)
    keep_ball_speed(ball)


def handle_collision(red_ball, blue_ball, current_time, last_collision_time):
    """Damage both balls and make them bounce apart when they collide."""
    dx = blue_ball["x"] - red_ball["x"]
    dy = blue_ball["y"] - red_ball["y"]
    distance = math.hypot(dx, dy)
    minimum_distance = BALL_RADIUS * 2

    if distance >= minimum_distance:
        return last_collision_time

    # Use a default direction if the centers are exactly on top of each other.
    if distance == 0:
        nx = 1
        ny = 0
    else:
        nx = dx / distance
        ny = dy / distance

    # Separate the balls so they do not stay overlapped.
    overlap = minimum_distance - distance
    red_ball["x"] -= nx * overlap / 2
    red_ball["y"] -= ny * overlap / 2
    blue_ball["x"] += nx * overlap / 2
    blue_ball["y"] += ny * overlap / 2

    # Bounce using the collision direction. This changes x and y velocity
    # depending on the angle where the balls hit.
    tx = -ny
    ty = nx

    red_normal_speed = red_ball["vx"] * nx + red_ball["vy"] * ny
    red_tangent_speed = red_ball["vx"] * tx + red_ball["vy"] * ty
    blue_normal_speed = blue_ball["vx"] * nx + blue_ball["vy"] * ny
    blue_tangent_speed = blue_ball["vx"] * tx + blue_ball["vy"] * ty

    red_ball["vx"] = blue_normal_speed * nx + red_tangent_speed * tx
    red_ball["vy"] = blue_normal_speed * ny + red_tangent_speed * ty
    blue_ball["vx"] = red_normal_speed * nx + blue_tangent_speed * tx
    blue_ball["vy"] = red_normal_speed * ny + blue_tangent_speed * ty

    keep_ball_speed(red_ball)
    keep_ball_speed(blue_ball)
    randomize_direction(red_ball)
    randomize_direction(blue_ball)

    # Prevent repeated damage while the balls are still touching.
    if current_time - last_collision_time < COLLISION_COOLDOWN:
        return last_collision_time

    red_ball["hp"] = max(0, red_ball["hp"] - DAMAGE)
    blue_ball["hp"] = max(0, blue_ball["hp"] - DAMAGE)

    return current_time


def get_winner(red_ball, blue_ball):
    """Return the winner text, or None if the round is still active."""
    if red_ball["hp"] <= 0 and blue_ball["hp"] <= 0:
        return "Draw!"
    if red_ball["hp"] <= 0:
        return "Blue Wins!"
    if blue_ball["hp"] <= 0:
        return "Red Wins!"
    return None


def draw_player_info(screen, x, y, hp, color, label, font):
    """Draw one ball's name, HP text, and health bar above the arena."""
    bar_width = 180
    bar_height = 25
    fill_width = int(bar_width * (hp / STARTING_HP))

    name_text = font.render(label, True, color)
    hp_text = font.render(f"HP: {hp}", True, WHITE)
    screen.blit(name_text, (x, y))
    screen.blit(hp_text, (x, y + 28))

    bar_y = y + 62
    pygame.draw.rect(screen, GRAY, (x, bar_y, bar_width, bar_height))
    pygame.draw.rect(screen, color, (x, bar_y, fill_width, bar_height))
    pygame.draw.rect(screen, WHITE, (x, bar_y, bar_width, bar_height), 2)


def draw_start_screen(screen, font, title_font):
    """Draw the title screen and return the Start button rectangle."""
    screen.fill(BLACK)

    title_text = title_font.render("Ball Battle", True, WHITE)
    title_rect = title_text.get_rect(center=(WINDOW_WIDTH // 2, 260))
    screen.blit(title_text, title_rect)

    # Draw the developer label on a transparent layer.
    label_surface = font.render("Developer: Luke Azhar", True, WHITE)
    label_surface.set_alpha(150)
    label_rect = label_surface.get_rect(center=(WINDOW_WIDTH // 2, 330))
    screen.blit(label_surface, label_rect)

    draw_button(screen, font, "Start", START_BUTTON_RECT)

    pygame.display.flip()
    return START_BUTTON_RECT


def draw_button(screen, font, text, rect):
    """Draw a simple centered button."""
    pygame.draw.rect(screen, WHITE, rect, border_radius=8)
    button_text = font.render(text, True, BLACK)
    button_rect = button_text.get_rect(center=rect.center)
    screen.blit(button_text, button_rect)


def draw_game(screen, state, font, big_font):
    """Draw the arena, balls, health bars, and winner message."""
    screen.fill(BLACK)

    red_ball = state["red"]
    blue_ball = state["blue"]

    draw_player_info(screen, 25, 25, red_ball["hp"], RED, "Red Ball", font)
    draw_player_info(screen, 245, 25, blue_ball["hp"], BLUE, "Blue Ball", font)

    # The balls fight only inside this square arena.
    pygame.draw.rect(screen, WHITE, (ARENA_X, ARENA_Y, ARENA_SIZE, ARENA_SIZE), 3)

    pygame.draw.circle(screen, red_ball["color"], (int(red_ball["x"]), int(red_ball["y"])), BALL_RADIUS)
    pygame.draw.circle(screen, blue_ball["color"], (int(blue_ball["x"]), int(blue_ball["y"])), BALL_RADIUS)

    if state["winner"] is not None:
        winner_text = big_font.render(state["winner"], True, GREEN)
        winner_rect = winner_text.get_rect(center=(WINDOW_WIDTH // 2, 365))

        screen.blit(winner_text, winner_rect)
        draw_button(screen, font, "Play Again", PLAY_AGAIN_BUTTON_RECT)
        draw_button(screen, font, "Main Menu", MAIN_MENU_BUTTON_RECT)

    pygame.display.flip()


def update_game(state):
    """Update movement and collision during active play."""
    red_ball = state["red"]
    blue_ball = state["blue"]

    move_ball(red_ball)
    move_ball(blue_ball)

    current_time = pygame.time.get_ticks() / 1000
    state["last_collision_time"] = handle_collision(
        red_ball,
        blue_ball,
        current_time,
        state["last_collision_time"],
    )
    state["winner"] = get_winner(red_ball, blue_ball)


async def wait_for_browser_start(screen, font):
    """Wait for a click or keypress before starting the browser game."""
    waiting = True

    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                waiting = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False

        screen.fill(BLACK)
        message = font.render("Click anywhere to continue", True, WHITE)
        message_rect = message.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2))
        screen.blit(message, message_rect)
        pygame.display.flip()

        await asyncio.sleep(0)


async def main():
    pygame.init()

    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption("Ball Battle - Day 1 Prototype")
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 30)
    big_font = pygame.font.Font(None, 70)

    await wait_for_browser_start(screen, font)

    state = reset_game()
    game_state = "start"
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_r:
                    state = reset_game()
                    game_state = "playing"
                elif game_state == "start" and event.key in (pygame.K_SPACE, pygame.K_RETURN):
                    state = reset_game()
                    game_state = "playing"
            elif game_state == "start" and event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and START_BUTTON_RECT.collidepoint(event.pos):
                    state = reset_game()
                    game_state = "playing"
            elif game_state == "game_over" and event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and PLAY_AGAIN_BUTTON_RECT.collidepoint(event.pos):
                    state = reset_game()
                    game_state = "playing"
                elif event.button == 1 and MAIN_MENU_BUTTON_RECT.collidepoint(event.pos):
                    state = reset_game()
                    game_state = "start"

        if game_state == "start":
            draw_start_screen(screen, font, big_font)
        else:
            if game_state == "playing":
                update_game(state)
                if state["winner"] is not None:
                    game_state = "game_over"

            draw_game(screen, state, font, big_font)

        clock.tick(FPS)
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    asyncio.run(main())
